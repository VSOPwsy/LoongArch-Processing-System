#ifndef __DDR_H
#define __DDR_H

int DDR_Init(void);


#endif

#ifndef __SD_H
#define __SD_H

int SD_Init(void);


#endif
